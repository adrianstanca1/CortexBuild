import{r,g as a}from"./react-DiZ9e1Sl.js";var s=r();const o=a(s);export{o as R,s as r};
